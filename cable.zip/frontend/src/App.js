import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import NavbarComponent from './components/NavabarComponent';
import ChannelList from './components/ChanelList';
import FilterComponet from './components/FilterComponent';

import BoquetDisplay from './components/BoquetDisplay';

import RecieptDisplay from './components/RecieptDisplay';


class App extends Component {

  _isMounted = false;

  constructor(props){
    super(props);
    this.state = {
      channelList : null,
      filteredChannelList : null,
      genres : null ,
      langugages : null,
      broadcasters : null,
      bouqetList : null,
      selectedChannels : [],
      error : null
    }
  }

  componentDidMount(){
    this._isMounted = true;
    const API_URL = "http://192.168.5.245:8080";

    axios.get(`${API_URL}/channel`).then((response) => {
      if(response.data){
        if(this._isMounted === true){
          this.setState({channelList : response.data})
        }
      }
    }).catch(err => this.setState({error : err}));

    axios.get(`${API_URL}/channel/genre`).then((response) => {
      if(response.data){
        if(this._isMounted === true){
          this.setState({genres : response.data})
        }
      }
    }).catch(err => this.setState({error : err}));

    axios.get(`${API_URL}/channel/language`).then((response) => {
      if(response.data){
        console.log(response.data);
        if(this._isMounted === true){
          this.setState({langugages : response.data})
        }
      }
    }).catch(err => this.setState({error : err}));

    axios.get(`${API_URL}/broadcaster`).then((response) => {
      if(response.data){
        console.log(response.data);
        if(this._isMounted === true){
          this.setState({broadcasters : response.data})
        }
      }
    }).catch(err => this.setState({error : err}));

    axios.get(`${API_URL}/boquet`).then((response) => {
      if(response.data){
        console.log(response.data);
        if(this._isMounted === true){
          this.setState({bouqetList : response.data})
        }
      }
    }).catch(err => this.setState({error : err}));

  }

  onFilterSelection(onTerm, withTerm){
    const API_URL = "http://192.168.5.245:8080";
    console.log(onTerm, withTerm);
    switch(onTerm) {
      case "Genre" : 
        axios.get(`${API_URL}/channel/genre/${withTerm}`).then((response) => {
          if(response.data){
            console.log(response.data);
            if(this._isMounted === true){
            this.setState({filteredChannelList : response.data})
            }
          }
        }).catch(err => this.setState({error : err}));
        break;

      case "Language" :
        axios.get(`${API_URL}/channel/language/${withTerm}`).then((response) => {
          if(response.data){
            console.log(response.data);

            if(this._isMounted === true){
              this.setState({filteredChannelList : response.data})
            }
           
          }
        }).catch(err => this.setState({error : err}));
        break;

      case "Broadcaster" : 
        axios.get(`${API_URL}/channel/broadcaster/${withTerm}`).then((response) => {
          if(response.data){
            console.log(response.data);
            if(this._isMounted === true){
            this.setState({filteredChannelList : response.data})
            }
          }
        }).catch(err => this.setState({error : err}));
      
      default: 
        console.log("no request");
    }
  }
  onItemSelection(selectedChannel){
    this.setState({
      selectedChannels: [...this.state.selectedChannels, selectedChannel]
    })
  }

  componentWillUnmount() {
    this._isMounted = false;
  }


  render() {
    return (
      <div className="App">
        <NavbarComponent />
        <div className="container">
          <div className="row">
            <div className="col-md-8">
                <FilterComponet onFilterSelection = { this.onFilterSelection.bind(this)} genres = { this.state.genres} languages = { this.state.langugages} broadcasters= {this.state.broadcasters} ></FilterComponet>
                <ChannelList channelList={this.state.channelList} filteredChannelList = { this.state.filteredChannelList} selectedChannels = {this.onItemSelection.bind(this)}/>
                <BoquetDisplay bouqetList= {this.state.bouqetList}/>
            </div>
            <div className="col-md-4">
              <RecieptDisplay selectedChannels = {this.state.selectedChannels}/>
            </div>
          </div>
        </div>
        
      </div>
    );
  }
}

export default App;
