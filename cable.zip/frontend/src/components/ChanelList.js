import React, { Component } from 'react'

class ChanelList extends Component {
    _isMounted = false;
    constructor(props){
        super(props);
        this.state = {
          channelsToShow : null
        }
        this.onItemSelection = this.onItemSelection.bind(this);
    }


    onItemSelection(channel){
      console.log(channel);
      this.props.selectedChannels(channel);
    }

    componentDidMount(){
      this._isMounted = true;
    }
    componentWillReceiveProps(nextProps){
      // console.log(nextProps);
      if(nextProps.filteredChannelList){
      return  this.setState({channelsToShow : nextProps.filteredChannelList});
      }
      if(this._isMounted === true){
        this.setState({channelsToShow : nextProps.channelList})
      }
     
    }
    componentWillUnmount(){
      this._isMounted = false;
    }
  render() {
    console.log(this.state.channelsToShow);
    var channelListItem = '';
    if(this.state.channelsToShow){
      channelListItem = this.state.channelsToShow.map((channel) => {
        return (
          <div className="col-md-3 mb-2 channel-card" key={channel._id}>
          <div className="card" >
            <div className="card-body">
              <p className="card-title">{channel.Name}</p>
              <p className="card-text"> &#8377; {channel.MRP}</p>
              <a href="#" className="btn" onClick= {() => this.onItemSelection(channel)}><i className="fas fa-plus-circle"></i></a>
            </div>
          </div>
          </div>
        )
      })
    }else{
      channelListItem = <div></div>;
    }
    

    return (
      <div className="py-4">
            <h6>Channel Offered :</h6>
            <div className="row channel-list-row border-bottom">
            {channelListItem}
            </div>
      </div>
    )
  }
}

export default ChanelList;