import React, { Component } from 'react'

class BoquetDisplay extends Component {
  render() {
      const boquets = this.props.bouqetList;
      var bouqetDisplayItem = ''
      if(boquets){
          bouqetDisplayItem = boquets.map((boquet) => {
              return (
                <div className="col-md-3 mb-2 channel-card" key={boquet._id}>
                    <div className="card" >
                        <div className="card-body">
                        <p className="card-title">{boquet.Name}</p>
                        <p className="card-text"> &#8377; {boquet.MRP}</p>
                        <a href="#" className="btn "><i className="fas fa-plus-circle"></i></a>
                        </div>
                    </div>
                </div>
              );
          })
      }
      else {
          bouqetDisplayItem = <div></div>
      }
      console.log(boquets);
    return (
      <div>
          <h6>Boquet Offered :</h6>
        <div className="row channel-list-row  pt-3">
            { bouqetDisplayItem}
        </div>
      </div>
    )
  }
}

export default BoquetDisplay;