import React, { Component } from 'react'

 class RecieptDisplay extends Component {


    constructor(props){
        super(props);
        this.state = {
            selectedChannels: null
        };
    }

    componentWillReceiveProps(nextProps){
        this.setState({selectedChannels : nextProps.selectedChannels});
    }

  render() {
    
    var selectedChannels = '';
    if(this.state.selectedChannels){
        selectedChannels = this.state.selectedChannels.map((selectedChannel, index) => {
            return (
                <tr key = { selectedChannel._id + 'slected'}>
                    <th scope="row">{index + 1}</th>
                    <td>{selectedChannel.Name}</td>
                    <td>{selectedChannel.Broadcaster.Name}</td>
                    <td>{selectedChannel.MRP}</td>
                 </tr>
            );
        });
    }else {
        selectedChannels = '';
    }
    if(this.state.selectedChannels){
        var priceRow = this.state.selectedChannels.reduce((total,channel) => {
            console.log(total)
            total = total + channel.MRP
        }, 0);
    }
   
    const totalRow = (<tr>
    <th scope="col-span-3"></th>
</tr>)

    return (
      <div>
        <table className="table">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Broadcaster</th>
                <th scope="col">MRP</th>
                </tr>
            </thead>
            <tbody>
                {selectedChannels}
                {totalRow}
            </tbody>
        </table>
      </div>
    )
  }
}


export default RecieptDisplay;