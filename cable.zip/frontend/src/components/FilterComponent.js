import React, { Component } from 'react'

 class FilterComponent extends Component {

    constructor(props){
        super(props);
        this.state = {
            seletedGenre : '',
            selectedLanguage : '',
            selectedBroadCaster : ''
        }

        this.onClickBroadcasterFilter = this.onClickBroadcasterFilter.bind(this);
        this.onClickGenreFilter = this.onClickGenreFilter.bind(this);
        this.onClickLanguageFilter = this.onClickLanguageFilter.bind(this);
    }



    onClickGenreFilter(genre){
        const genreTerm = genre;
        const onTerm = "Genre";
        this.setState({seletedGenre : genreTerm});
        this.props.onFilterSelection(onTerm,genreTerm);
    }

    onClickLanguageFilter(langugae){
        const languageTerm = langugae;
        const onTerm = "Language";
        this.setState({selectedLanguage : languageTerm});
        this.props.onFilterSelection(onTerm,languageTerm);
    }

    onClickBroadcasterFilter(broadcaster){
        const broadcasterTerm = broadcaster._id;
        const onTerm = "Broadcaster";
        this.setState({selectedBroadCaster : broadcaster.Name});
        this.props.onFilterSelection(onTerm,broadcasterTerm);
    }

  render() {
    var genreFilterOption = '';
    if(this.props.genres) {
        genreFilterOption = this.props.genres.map((genre) => {
            return (
                <a key = {genre} className="dropdown-item" href="#" onClick = {() => this.onClickGenreFilter(genre)}>{genre}</a>
            )
        });
    }else {
        genreFilterOption = <div></div>;
    }

    var languageFilterOption = '';
    if(this.props.languages) {
        languageFilterOption = this.props.languages.map((language) => {
            return (
                <a key = {language} className="dropdown-item" href="#" onClick = {() => this.onClickLanguageFilter(language)}>{language}</a>
            )
        });
    }else {
        languageFilterOption = <div></div>;
    }

    var broadcasterFilterOption = '';
    if(this.props.broadcasters) {
        broadcasterFilterOption = this.props.broadcasters.map((broadcaster) => {
            return (
                <a key = {broadcaster._id} className="dropdown-item" onClick = {() => this.onClickBroadcasterFilter(broadcaster)} href="#">{broadcaster.Name}</a>
            )
        });
    }else {
        broadcasterFilterOption = <div></div>;
    }

    return (
        <div className="row my-3">
            <div className="genreFilter">
                <div className="dropdown">
                    <button className="btn btn-secondary dropdown-toggle" type="button" id="genreFilterOption" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {this.state.seletedGenre || 'Genre'}
                    </button>
                    <div className="dropdown-menu" aria-labelledby="genreFilterOption">
                        {genreFilterOption}
                    </div>
                </div>
            </div>
            <div className="languageFilter ml-3">
                <div className="dropdown">
                    <button className="btn btn-secondary dropdown-toggle" type="button" id="languageFilterOption" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {this.state.selectedLanguage || 'Languages' }
                    </button>
                    <div className="dropdown-menu" aria-labelledby="languageFilterOption">
                        {languageFilterOption}
                    </div>
                </div>
            </div>
            <div className="languageFilter ml-3">
                <div className="dropdown">
                    <button className="btn btn-secondary dropdown-toggle" type="button" id="broadcasterFilterOption" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                       { this.state.selectedBroadCaster  || "Broadcaster"}
                    </button>
                    <div className="dropdown-menu" aria-labelledby="broadcasterFilterOption">
                        {broadcasterFilterOption}
                    </div>
                </div>
            </div>
        </div>
    )
  }
}


export default FilterComponent;